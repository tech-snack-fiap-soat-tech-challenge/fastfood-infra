# 🍔 fastfood-auth-lambda

Lambda de autenticação para o sistema de pedidos de fast food. Este projeto tem como objetivo realizar o fluxo de registro e login de usuários utilizando Amazon Cognito e CPF como identificador único.

## 🚀 Descrição

Esta função Lambda foi desenvolvida para gerenciar a autenticação de clientes em um sistema de pedidos self-service para restaurantes fast food. A autenticação é feita com base no CPF do cliente, permitindo:

- 📥 **Cadastro de usuário (sign-up)** no Cognito
- 🔑 **Login de usuário (sign-in)** via CPF e geração de token JWT

## 🛠️ Tecnologias Utilizadas

- **Node.js** (runtime da Lambda)
- **Amazon Cognito** (gerenciamento de usuários)
- **AWS Lambda** (execução serverless)
- **AWS SDK** (integração com os serviços AWS)

## 📂 Estrutura do Projeto

```
fastfood-auth-lambda/
├── src/
│   ├── handlers/
│   │   ├── signup.js
│   │   └── login.js
│   ├── services/
│   │   └── cognitoService.js
│   └── utils/
│       └── responseHelper.js
├── package.json
├── package-lock.json
└── README.md
```

## ⚙️ Configuração

1. Configure as variáveis de ambiente da Lambda com:
   - `USER_POOL_ID`: ID do User Pool do Cognito
   - `CLIENT_ID`: ID do App Client do Cognito (sem secret)
   - `AWS_REGION`: Região da AWS onde o User Pool está localizado

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Empacote e publique a Lambda conforme o fluxo da sua pipeline ou via AWS CLI.

## 📌 Funcionalidades

### 🔵 Cadastro (`signup.js`)
- Recebe nome, email e CPF do usuário
- Cria um usuário no Cognito com CPF como `username`

### 🟢 Login (`login.js`)
- Recebe o CPF do usuário
- Autentica e retorna o token JWT do Cognito

## ✅ Pré-requisitos

- Conta na AWS com permissões para Cognito e Lambda
- User Pool Cognito configurado com CPF como atributo personalizado ou campo de `username`

## 🧪 Testes Locais

Você pode testar localmente usando o `AWS SAM CLI` ou ferramentas como o `serverless framework`. Para testes rápidos:

```bash
node src/handlers/signup.js
node src/handlers/login.js
```

## 🤝 Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou enviar pull requests.

## 📄 Licença

Este projeto é de uso acadêmico e temporário.

---

Feito com ❤️ para o projeto de arquitetura de software.
